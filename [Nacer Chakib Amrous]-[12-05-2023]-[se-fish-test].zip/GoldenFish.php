<?php


include('Fish.php');

class goldenFish extends Fish{

    public $type;
    public $randomNumber;
    public $speed ;
    public $text;
    public $number;

    public function __construct($x)
    {
        $this->type= $this->setFishType($x);
        $this->positionX = rand(1,20);
        $this->positionY = rand(1,20);
        $this->speed= $this->setSpeed(3);
        $this->name = $this->getFishName(3);
        $this->number =$x;
    }


    public function setFishType($x){
        if($x ==0 || $x==1){
            return $this->type="Gurame";
        }elseif($x ==2 || $x==3){
            return $this->type="Nila";
        }else{
            return $this->type="Bawal";
        }
    }

    public function setSpeed($speed) {
		return $this->speed = rand(1,$speed);
	}

    public function draw(){
		$this->text= "\033[".$this->positionX.";".$this->positionY."f fish #".$this->name." type ".$this->type;
		switch($this->number){
			case 0:
		echo "\033[01;31m ". $this->text." \033[0m";
			break;

				case 1:
			echo "\033[01;32m ". $this->text." \033[0m";
				break;

				case 2:
					echo "\033[01;33m ". $this->text." \033[0m";
						break;

						case 3:
							echo "\033[01;34m ". $this->text." \033[0m";
								break;

								case 4:
									echo "\033[01;35m ". $this->text." \033[0m";
										break;
										case 5:
											echo "\033[01;36m ". $this->text." \033[0m";
												break;
		}
		
	}


    public function move() {
	 $this->randomNumber= rand(0,3);
    
     if($this->randomNumber==0){
         $this->positionX += $this->speed;
     }
     elseif($this->randomNumber==1){
         $this->positionX -= $this->speed;
         if($this->positionX <= 0){
            $this->positionX = 4;
         }
     }
     elseif($this->randomNumber==2){
         $this->positionY -= $this->speed;
         if($this->positionY <= 0){
            $this->positionY = 4;
         }
     }
     else{
             $this->positionY += $this->speed;
         }
     



		$this->draw();
    }

}