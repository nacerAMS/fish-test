<?php
/**
 *	allowed to edit
 * 
 */
include('GoldenFish.php');

Class Pond {

	/**
	 * make new fish object in pond and return array of object fish
	 * @return array array of object fish
	 */
	public function getFish() {
		$fish = [];
		for($i = 0; $i <= 5; $i++) {
			$fish[$i] = new goldenFish($i);
		}
		return $fish;
	}
}