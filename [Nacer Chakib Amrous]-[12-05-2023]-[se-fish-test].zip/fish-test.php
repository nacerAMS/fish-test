<?php
/**
 * Open Comand Line and run
 * php fish-test.php
 */

include('./World.php');

new World;