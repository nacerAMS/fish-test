## Vesperia Test
in the fish pond there are 3 koi fish, you must complete task below to proceed:
- Make new Fish Type (Gurame, Nila, Bawal) with diferent speed and text color
- Add more Fish in Pond, 2 each type
- Change animated fish name [name]-[type]
- Make fish change direction randomly (UP, DOWN, LEFT, RIGHT)
- Make fish not to swim above the pond
- Allowed to edit Pond.php and add files with inheritance from Fish class

## run files
open command line and run
```
php fish-test.php
```

### notes
- you must run with linux terminal or terminal emulator that support position print
- in order to view the expected result, you can view the attached sample videos